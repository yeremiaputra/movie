package com.yere.movie_application.model;

import java.io.Serializable;

/**
 * Created by Yeremia Putra on 10-04-2021.
 */

public class ModelTrailer implements Serializable {

    private String key;
    private String type;

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
